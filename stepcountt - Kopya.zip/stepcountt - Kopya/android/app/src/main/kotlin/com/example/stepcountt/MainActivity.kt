package com.example.stepcountt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
