import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stepcountt/core/extension/context_extentsion.dart';

class CustomButton extends StatelessWidget {
  const CustomButton({
    Key? key,
    double height=27,
    required String title,
    Widget? nextScreen,
  })  : _title = title,
        _height = height,
        _nextScreen = nextScreen,
        super(key: key);
  final double _height;
  final String _title;
  final Widget? _nextScreen;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: this._height,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black
          ),
          onPressed: () {

            if (_nextScreen != null) {
              Navigator.push(context,
                  CupertinoPageRoute(builder: (context) => _nextScreen!));
            }
          },
          child: Text(
            _title,
            style: Theme.of(context)
                .textTheme
                .headline6
                ?.copyWith(color: Colors.white),
          )),
    );
  }
}
