import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stepcountt/core/extension/context_extentsion.dart';

class DetailGraph extends StatelessWidget {
  const DetailGraph({
    Key? key,
    required String title,
    required String title1,
    required String title2,
    required String title3,

  })  : _title = title,
        _title1 = title1,
        _title2 = title2,
        _title3 = title3,
        super(key: key);

  final String _title;
  final String _title1;
  final String _title2;
  final String _title3;

  Widget build(BuildContext context) {
    return Container(
      width:  context.dynamicWith(1),
      height: context.dynamicHeight(0.06),
      child: Row(
        children: [
          Container(
            width:  context.dynamicWith(0.12),
            height: context.dynamicHeight(0.08),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Color.fromARGB(249, 12, 12, 12)),
            child: Image.asset('assets/images/ic_walk.png'),
          ),
          SizedBox(
            width: context.dynamicWith(0.08),
          ),
          Column(
            children: [
              Text(
                this._title,
                style: Theme.of(context)
                    .textTheme
                    .subtitle1
                    ?.copyWith(color: Colors.white),
              ),
              Row(
                children: [
                  Text(
                    this._title1,
                    style: Theme.of(context)
                        .textTheme
                        .caption
                        ?.copyWith(color: Colors.white70),
                  ),
                  SizedBox(
                    height:context.dynamicHeight(0.03),
                    width: context.dynamicWith(0.2),
                  ),

                  Text(
                    this._title2,
                    style: Theme.of(context)
                        .textTheme
                        .caption
                        ?.copyWith(color: Colors.white70),
                  ),
                ],
              )
            ],
          ),
          SizedBox(
            width:context.dynamicWith(0.13),
          ),
          Column(
            children: [
              Row(
                children: [
                  Text(
                    "3,25",
                    style: Theme.of(context)
                        .textTheme
                        .subtitle1
                        ?.copyWith(color: Colors.white),
                  ),
                  SizedBox(width:context.dynamicWith(0.03)),
                  Image.asset("assets/images/ic_coin.png")
                ],
              ),
              SizedBox(
                height:context.dynamicHeight(0.003)),
              Text(
                this._title3,
                style: Theme.of(context)
                    .textTheme
                    .caption
                    ?.copyWith(color: Colors.white70),
              )
            ],
          )
        ],
      ),
    );
  }
}
