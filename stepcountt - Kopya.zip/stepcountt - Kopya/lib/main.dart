import 'package:flutter/material.dart';
import 'package:stepcountt/screens/graphs_screen.dart';
import 'package:stepcountt/theme/dark_theme.dart';
import 'package:stepcountt/theme/light_theme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Step App',
      debugShowCheckedModeBanner: false,
      theme: LightTheme().theme,
      darkTheme: DarkTheme().theme,
      themeMode: ThemeMode.dark,
      home: GraphScreen(),
    );
  }

}
