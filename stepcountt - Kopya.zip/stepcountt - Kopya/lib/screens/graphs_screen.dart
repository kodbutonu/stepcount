import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stepcountt/core/extension/context_extentsion.dart';
import 'package:stepcountt/custom_widgets/custom_button.dart';

import '../custom_widgets/custom_introduction.dart';

class GraphScreen extends StatelessWidget {
  final _graphFeatures = _GraphFeatures();
  final _introTitle = _IntroTitle();
  static String routeName = "GraphScreen";
  GraphScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: SystemUiOverlayStyle.light,
        foregroundColor: Theme.of(context).colorScheme.onSecondary,
      ),
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        padding: EdgeInsets.only(left: context.dynamicHeight(0.05)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: CustomButton(
                    title: _graphFeatures.todayTitle,

                  ),
                ),
                Expanded(
                  child: CustomButton(
                    title: _graphFeatures.monthTitle,

                  ),
                ),
                Expanded(
                  child: CustomButton(
                    title: _graphFeatures.yearTitle,

                  ),
                ),
              ],
            ),
            SizedBox(
              height:context.dynamicHeight(0.08),
              ),
            DetailGraph(title:_introTitle.todayTitle,
                title1: _introTitle.dkTitle,
                title2: _introTitle.kmTitle,
                title3: _introTitle.hoursTitle),
            SizedBox(height: context.dynamicHeight(0.04),),
            DetailGraph(title:_introTitle.todayTitle,
                title1: _introTitle.dk1Title,
                title2: _introTitle.km1Title,
                title3: _introTitle.hoursTitle),
            SizedBox(height: context.dynamicHeight(0.04),),
            DetailGraph(title:_introTitle.todayTitle,
                title1: _introTitle.dk2Title,
                title2: _introTitle.km1Title,
                title3: _introTitle.hoursTitle),
            SizedBox(height:  context.dynamicHeight(0.04),),
            DetailGraph(title:_introTitle.todayTitle,
                title1: _introTitle.dkTitle,
                title2: _introTitle.km3Title,
                title3: _introTitle.hoursTitle),
          ],

        ),
      ),
    );
  }
}

class _GraphFeatures {
  final String todayTitle = "Bugün";
  final String monthTitle = "BuHafta";
  final String yearTitle = "Bu Ay";
}

class _IntroTitle {
  final String todayTitle = "Yürüyüş Aktivitesi";
  final String dkTitle = '10dk';
  final String dk1Title = '5dk';
  final String dk2Title = '2dk';
  final String kmTitle = '2km';
  final String km1Title = '10km';
  final String km2Title = '8km';
  final String km3Title = '100m';
  final String hoursTitle = 'Ö.Ö.09.45';
}
