import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stepcountt/theme/product_colors.dart';


class DarkTheme {
  late ThemeData theme;

  final _colors = ProductColors();

  DarkTheme() {
    theme = ThemeData(
        fontFamily: "Urbanist",
        scaffoldBackgroundColor: _colors.black19,

        // AppBar Theme
        appBarTheme: AppBarTheme(
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
            systemOverlayStyle: SystemUiOverlayStyle.light,
            titleTextStyle: TextStyle(color: _colors.white)),

        // Input Decoration
        inputDecorationTheme: InputDecorationTheme(
          prefixIconColor: _colors.white,
          suffixIconColor: _colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: _colors.white),
              borderRadius: BorderRadius.circular(15)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(19),
              borderSide: BorderSide(color: _colors.white)),
        ),

        // Text Theme
        textTheme: TextTheme(
          subtitle1: TextStyle(color: _colors.white),
        ),

        // ElevatedButton Theme
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
              alignment: Alignment.center,
              foregroundColor: MaterialStateProperty.all(_colors.black19),
              textStyle:
              MaterialStateProperty.all(TextStyle(color: _colors.black19)),
              backgroundColor: MaterialStateProperty.all(_colors.white),
              shape: MaterialStateProperty.all(
                  RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
            )),

        //  CheckBox Theme
        checkboxTheme: CheckboxThemeData(
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
            fillColor: MaterialStateProperty.all(_colors.white),
            checkColor: MaterialStateProperty.all(_colors.black19)),

        // Card Theme
        cardTheme: CardTheme(
            elevation: 2,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10))),

        // Circle Progress Indicator

        // Color Scheme
        colorScheme: ColorScheme(
            brightness: Brightness.dark,
            primary: _colors.black19,
            onPrimary: _colors.black,
            secondary: _colors.white,
            onSecondary: _colors.white,
            error: _colors.exitButtonRed,
            onError: _colors.exitButtonRed,
            background: _colors.green,
            onBackground: _colors.targetChartRed,
            surface: _colors.yellow,
            onSurface: _colors.lightBackColor));
  }
}
