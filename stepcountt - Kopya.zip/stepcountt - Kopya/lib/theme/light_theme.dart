import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stepcountt/theme/product_colors.dart';


class LightTheme {
  late ThemeData theme;
  final _colors = ProductColors();

  LightTheme() {
    theme = ThemeData(
        fontFamily: "Urbanist",
        scaffoldBackgroundColor: _colors.lightBackColor,

        // AppBar Theme
        appBarTheme: AppBarTheme(
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
            systemOverlayStyle: SystemUiOverlayStyle.dark,
            titleTextStyle: TextStyle(color: _colors.black)),

        // Input Decoration
        inputDecorationTheme: InputDecorationTheme(
          prefixIconColor: _colors.white,
          suffixIconColor: _colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: _colors.white),
              borderRadius: BorderRadius.circular(15)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(19),
              borderSide: BorderSide(color: _colors.white)),
        ),

        // Text Theme
        textTheme: TextTheme(subtitle1: TextStyle(color: _colors.white)),

        // ElevatedButton Theme
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
              alignment: Alignment.center,
              foregroundColor: MaterialStateProperty.all(_colors.black19),
              textStyle:
              MaterialStateProperty.all(TextStyle(color: _colors.black19)),
              backgroundColor: MaterialStateProperty.all(_colors.white),
              shape: MaterialStateProperty.all(
                  RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
            )),

        //  CheckBox Theme
        checkboxTheme: CheckboxThemeData(
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
            fillColor: MaterialStateProperty.all(_colors.white),
            checkColor: MaterialStateProperty.all(_colors.black19)),

        // Card Theme
        cardTheme: CardTheme(
            elevation: 2,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10))),

        // Color Scheme
        colorScheme: ColorScheme(
            brightness: Brightness.light,
            primary: _colors.purple,
            onPrimary: _colors.black,
            secondary: _colors.black19,
            onSecondary: _colors.white,
            error: _colors.exitButtonRed,
            onError: _colors.exitButtonRed,
            background: _colors.green,
            onBackground: _colors.targetChartRed,
            surface: _colors.yellow,
            onSurface: _colors.lightBackColor));
  }
}
