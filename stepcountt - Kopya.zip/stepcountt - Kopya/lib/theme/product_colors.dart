import 'package:flutter/material.dart';

enum ProductColor {
  purple,
  white,
  black19,
  black,
  lightBackColor,
  targetChartRed,
  exitButtonRed,
  green,
  yellow,
  darkCardColor,
}

class ProductColors {
  final Color purple = const Color.fromARGB(255, 88, 55, 208);
  final Color white = const Color.fromARGB(255, 255, 255, 255);
  final Color black19 = const Color.fromARGB(255, 25, 25, 25);
  final Color black = const Color.fromARGB(255, 0, 0, 0);
  final Color lightBackColor =
  const Color.fromARGB(255, 255, 255, 255).withOpacity(0.97);
  final Color targetChartRed = const Color.fromARGB(255, 195, 49, 84);
  final Color exitButtonRed = const Color.fromARGB(255, 174, 68, 68);
  final Color green = const Color.fromARGB(255, 49, 195, 116);
  final Color yellow = const Color.fromARGB(255, 255, 187, 13);
  final Color darkCardColor = const Color.fromARGB(255, 34, 34, 34);

}
